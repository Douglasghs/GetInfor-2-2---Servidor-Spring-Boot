package com.example.GetInfor.GetInfor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GetInforApplication {

	public static void main(String[] args) {
		SpringApplication.run(GetInforApplication.class, args);
	}

}
